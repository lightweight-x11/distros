<?php 
 class DB extends DBmysql { 
 var $dbhost	= 'localhost'; 
 var $dbuser 	= 'glpi'; 
 var $dbpassword= 'glpi'; 
 var $dbdefault	= 'glpi'; 
 } 
 ?>