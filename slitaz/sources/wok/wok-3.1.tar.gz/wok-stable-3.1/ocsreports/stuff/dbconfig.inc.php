<?php 
$_SESSION["SERVEUR_SQL"]="localhost";
$_SESSION["COMPTE_BASE"]="ocs";
$_SESSION["PSWD_BASE"]="ocs";
?>