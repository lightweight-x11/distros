#!/bin/sh
#
# Clean up original Faenza icon theme for SliTaz.
# Pankso - <pankso@slitaz.org>
#

dir=$1
[ -d "$dir" ] || exit 0
size=$(du -sh $dir | awk '{print $1}')

echo -n "Optimizing for size $dir... "

# Unused and unuseful
rm -rf $dir/emblems
rm -rf $dir/stock/io
rm -rf $dir/extras

# Keep only 32x32 22x22
for i in scalable 96 64 48 24 16
do
	rm -rf $dir/*/$i
done

# 32 keep: mimetypes place status
for i in actions apps categories devices stock
do
	rm -rf $dir/$i/32
done

# 32/status clean
for f in weather skype apt
do
	rm -f $dir/status/32/*$f*
done

# 32/places clean
for f in archlinux fedora mandriva suse gentoo ubuntu mint frugalware debian \
	slack
do
	rm -f $dir/places/32/*$f*
done


# Remove 22, 32 are resized by gdk-pixbuf and ok for panel
for i in status places mimitypes
do
	rm -rf $dir/$i/22
done

# Clean apps/22
for i in google .xpm ubuntu picasa opera office Thunar thund java sun \
	spotify sound skype scribes rhythmbox qt phatch open ooo nm- nautilus \
	mono linguist last ice im- ibus gwibber haguichi goa- facebook gnome-panel \
	gnome-robots gnome-do gmail glade glippy gloobus gksu gdm flickr flash \
	firefox file fedora f-spot evince emesene empathy eog chromium ccc_ anjuta \
	amazon amorak adobe Adobe acroread zim yahoo youtube xpad xfce4-panel \
	autoplus banshee baobab ++ devhelp defcon devede desura docky dropbox \
	eclipse emerald gnome-tali gnome-sudoku gnome-tetravex menu-editor minitunes \
	minitube miro nvidia playonlinux ppa telepathy terminator time-admin tomboy \
	tracker tvtime umusicstore wordpress xbmc wxbanker
do
	rm -f $dir/apps/22/*$i*
done

echo "OK"
echo "Original: $size"
echo -n "New size: "
du -sh $dir | awk '{print $1}'

exit 0
