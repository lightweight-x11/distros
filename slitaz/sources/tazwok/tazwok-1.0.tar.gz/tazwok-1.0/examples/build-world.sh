#!/bin/sh
#
# This script let you compile, generate package and directly install them
# into the host system. Use at you own risk, it can break you all system.
# - Pankso
#

# Wok and packages directories (must match your tazwok.conf).
#
WOK="/home/slitaz/wok"
PACKAGES_REPOSITORY="/home/slitaz/packages"

# Script functions.
#

# Check for a specified file list on cmdline.
check_for_list()
{
	if [ -z "$2" ] ; then
		echo "You must specify the path to the list of packages to cook."
		exit 0
	fi
	# Check if the list of packages exist.
	if [ -f "$2" ] ; then
		LIST=`cat $2`   
	else
		echo "Unable to find $2 packages list."
		exit 0
	fi
}

# Build world is designated to rebuild the full system by installing
# the compiled/generated packages in to the host, this is done to
# link applications with the good libs.
#
check_for_list
echo "Warning, build-world is dangerous for the host system."
echo -n "Continue (y/N) :" ; read anser
if [ ! "$anser" = "y" ] ; then
	echo "Exiting."
	exit 0
fi
# Do the job, exec Tazwok to compile and genpkg, and then install
# with Tazpkg.
#
for pkg in $LIST
do
	tazwok compile $pkg
	tazwok genpkg $pkg
	cd $PACKAGES_REPOSITORY
	. $WOK/$pkg/receipt
	tazpkg install $PACKAGE-$VERSION.tazpkg
done
