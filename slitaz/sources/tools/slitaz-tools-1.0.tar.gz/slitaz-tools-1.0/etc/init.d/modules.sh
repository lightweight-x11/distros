#!/bin/sh
# /etc/init.d/modules.sh: Linux kernel modules 
# initialisation on SliTaz GNU/Linux.
#
. /etc/init.d/rc.functions

echo "Processing /etc/init.d/modules.sh to probe kernel modules... "

# Load modules with modprobe.
#
echo -n "Loading vfat module... "
modprobe vfat
status

#echo -n "Loading nls_utf8 module... "
#modprobe nls_utf8
#status

