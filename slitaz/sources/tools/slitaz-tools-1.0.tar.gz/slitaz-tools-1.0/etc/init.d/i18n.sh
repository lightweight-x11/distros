#!/bin/sh
# /etc/init.d/i18n.sh: Internalisation initialisation.
# This script configure SliTaz default keymap and locale.
#
. /etc/init.d/rc.functions

# Locale config.
#
echo "Cheking if /etc/locale.conf exist... "
if [ -f "/etc/locale.conf" ]; then
  echo -n "Locale configuration file exist... "
  status
else
  tazlocale
fi

# Keymap config.
#
if [ -f "/etc/kmap.conf" ]; then
  # Load keymap with Busybox loadkmap.
  . /etc/kmap.conf
  echo -n "Loading keymap: $KMAP... "
  busybox loadkmap < /usr/share/kmap/$KMAP
  status
else 
  tazkmap
fi

