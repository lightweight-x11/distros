#!/bin/sh
# /etc/init.d/local.sh: Local startup commands.
# All commands here will be executed at boot time.
#
. /etc/init.d/rc.functions
echo "Starting local startup commands... "

