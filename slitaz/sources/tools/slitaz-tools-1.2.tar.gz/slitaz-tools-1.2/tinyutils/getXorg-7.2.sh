#!/bin/sh
# getXorg-7.2.sh: This scripts download the Xserver Xorg7.2 from
# the freedesktop mirror.
#

echo "Get Xorg 7.2 for SliTaz... "

# Proto.
mkdir -p proto && cd proto
wget http://xorg.freedesktop.org/releases/X11R7.2/src/proto/bigreqsproto-X11R7.0-1.0.2.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/proto/renderproto-X11R7.0-0.9.2.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/proto/inputproto-X11R7.0-1.3.2.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/proto/kbproto-X11R7.2-1.0.3.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/proto/xcmiscproto-X11R7.0-1.1.2.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/proto/xextproto-X11R7.0-7.0.2.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/proto/xproto-X11R7.2-7.0.10.tar.gz
cd ..
# Lib.
mkdir -p lib && cd lib
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libICE-X11R7.2-1.0.3.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libSM-X11R7.2-1.0.2.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libX11-X11R7.2-1.1.1.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libXau-X11R7.2-1.0.3.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libXaw-X11R7.1-1.0.2.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libXdmcp-X11R7.2-1.0.2.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libXext-X11R7.2-1.0.2.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libXft-X11R7.2-2.1.12.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libXmu-X11R7.2-1.0.3.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libXpm-X11R7.2-3.5.6.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libXrender-X11R7.2-0.9.2.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libXt-X11R7.2-1.0.4.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/xtrans-X11R7.2-1.0.3.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/lib/libfontenc-X11R7.2-1.0.4.tar.gz
cd ..
# Data.
#mkdir -p data && cd data
#wget http://xorg.freedesktop.org/releases/X11R7.2/src/data/xbitmaps-X11R7.0-1.0.1.tar.gz
#cd ..
# App.
mkdir -p app && cd app
wget http://xorg.freedesktop.org/releases/X11R7.2/src/app/rgb-X11R7.1-1.0.1.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/app/xsetroot-X11R7.0-1.0.1.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/app/mkfontdir-X11R7.1-1.0.2.tar.gz
wget http://xorg.freedesktop.org/releases/X11R7.2/src/app/mkfontscale-X11R7.2-1.0.3.tar.gz
cd ..

echo ""
echo "Script end."
echo ""
