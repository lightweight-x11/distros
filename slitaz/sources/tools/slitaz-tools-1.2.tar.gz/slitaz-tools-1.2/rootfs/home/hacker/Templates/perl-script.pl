#!/usr/bin/perl
#

# Commentaire.

print "Hello world!\n"
