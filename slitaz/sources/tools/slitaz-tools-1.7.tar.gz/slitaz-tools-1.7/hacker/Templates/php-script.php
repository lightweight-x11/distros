<?php

// Un commentaire.

echo "Ce texte est affich� avec echo.";

?>
