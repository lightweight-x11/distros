#!/bin/sh
#

# Content type.
echo Content-Type: text/plain
echo ""

# Page content.
echo "Text file powered by SHell script."

