#!/bin/sh
# /etc/init.d/modules.sh: Linux kernel modules 
# initialization on SliTaz GNU/Linux.
#
. /etc/init.d/rc.functions

echo "Processing /etc/init.d/modules.sh to load kernel modules... "

# Load modules with modprobe.
#
modprobe vfat
modprobe nls_utf8

