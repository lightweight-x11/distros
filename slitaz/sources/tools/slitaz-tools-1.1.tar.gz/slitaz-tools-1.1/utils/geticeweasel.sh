#!/bin/sh
# geticeweasel.sh: Download and install IceWeasel
# prebuild binary. SliTaz GNU/Linux 2007.
#

NAME="IceWeasel"
SRC_URL=http://gnuzilla.gnu.org/download/iceweasel-1.5.0.7-g2-i386.tar.bz2
PACKAGE_NAME=iceweasel-1.5.0.7-g2-i386
PACKAGE=$PACKAGE_NAME.tar.bz2
INSTALL_DIR=/usr/bin

install_commands()
{
  echo "Processing install commands... "
  cd $INSTALL_DIR
  ln -s $PACKAGE_NAME/iceweasel iceweasel
}

# Check if user is root.
#
if test $(id -u) != 0; then
  echo ""
  echo "You must be root to run `basename $0`!"
  echo "Type su and root password to become super-user."
  echo ""
  exit 1
fi

# Confirm installation.
echo ""
echo "This script will install $PACKAGE_NAME on your system."
echo "Install dir: $INSTALL_DIR"
echo ""
echo -n "Please confirm (yes/no): " ; read anser
if [ "$anser" = "yes" ] ; then
  continue
else
  echo "Installation cancelled."
  exit 0
fi

# Installation.
cd /tmp
wget $SRC_URL
echo "Untaring: $PACKAGE... "
tar xjf $PACKAGE
echo "Moving $PACKAGE_NAME to $INSTALL_DIR"
mv $PACKAGE_NAME $INSTALL_DIR
install_commands
rm /tmp/$PACKAGE
echo "$PACKAGE_NAME is installed."
echo "Type: $ iceweasel &, in a terminal to start $NAME."
echo "You can also add an entry in your WM menu."

exit 0

