#!/bin/sh
#

# Comment.

echo "Hello world!"

# Variables.
NAME=

# Functions.
example()
{
  echo "This is a function."
}

