#!/usr/bin/lua

print "Hello World!"
